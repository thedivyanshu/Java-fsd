package PracticeProject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {

	public static void main(String[] args) {
		String regExpression = "[A-Z]";
		String text = "Hi Everyone this is an Example of Regular Expression in Java ";

		Pattern checking = Pattern.compile(regExpression);
		Matcher match = checking.matcher(text);

		while(match.find())
			System.out.println(text.substring(match.start(),match.end()));

	}

}
