package PracticeProject;

public class TryCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number1=5,number2=0;
		try {
			int result=number1/number2;
		}
		catch(ArithmeticException e) {
			System.out.println("ArithmeticException");
		}
		System.out.println("Cannot divide by Zero");
	}
}
