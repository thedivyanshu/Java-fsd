package PracticeProject;
import java.util.Scanner;
public class MatrixMultiply {
	//method for input of the matrix
	public static void inputMatrixElements(Scanner scanner, int[][] matrix, int rows, int columns) {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				matrix[i][j] = scanner.nextInt();
			}
		}
	}
	//method for matrix multiplication
	public static void matrixMultiply(int[][] matrix1, int[][] matrix2, int[][] product) {
		for (int i = 0; i < matrix1.length; i++) {
			for (int j = 0; j < matrix2[0].length; j++) {
				for (int k = 0; k < matrix1[0].length; k++) {
					product[i][j] += matrix1[i][k] * matrix2[k][j];
				}
			}
		}
	}
	//method for displaying matrix
	public static void showMatrix(int[][] matrix, int rows, int cols) {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of rows and columns for the first matrix:");
		int row1 = sc.nextInt();
		int column1 = sc.nextInt();
		System.out.println("Enter the number of rows and columns for the second matrix:");
		int row2 = sc.nextInt();
		int column2 = sc.nextInt();
		if (column1 != row2) {
			System.out.println("Matrix multiplication is not possible. Number of columns in the first matrix must be equal to the number of rows in the second matrix.");
			return;

		}

		int[][] matrix1 = new int[row1][column1];
		int[][] matrix2 = new int[row2][column2];
		int[][] product = new int[row1][column2];

		System.out.println("Enter elements of the first matrix:");
		inputMatrixElements(sc, matrix1, row1, column1);

		System.out.println("Enter elements of the second matrix:");
		inputMatrixElements(sc, matrix2, row2, column2);

		// Multiply the matrices
		matrixMultiply(matrix1, matrix2, product);

		// Display the product matrix
		System.out.println("Product Matrix:");
		showMatrix(product, row1, column2);
		sc.close();
	}
}
