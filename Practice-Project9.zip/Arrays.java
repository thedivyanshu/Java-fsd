package PracticeProject;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("One Dimensional Array");
		int numbers[] = {3,6,9,12,15,18,21};
		for(int i=0;i<numbers.length;i++) {
			System.out.println("Elements of arrays are" +" "+numbers[i]);
		}
		
		System.out.println("Two Dimensional Array");
		int matrix[][] = {{3,6,9},{5,10,15}};
		for(int i=0;i<matrix.length;i++) {
			for(int j=0;j<matrix[0].length;j++) {
			System.out.println(matrix[i][j] + "\t");
		}
			System.out.println();
	}

}
}