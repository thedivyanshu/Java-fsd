package PracticeProject;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class Maps<key, value> {
	Map<key, value>Map;
	public static void main(String[] args) {

		//Using Hashmap
		HashMap<Integer,String> department1=new HashMap<Integer,String>();      
		department1.put(12,"Mayank");    
		department1.put(22,"Avinash");    
		department1.put(32,"Neeraj");   

		System.out.println("\nThe Employee of Department1 are  ");    
		for(Map.Entry format:department1.entrySet()){    
			System.out.println(format.getKey()+" "+format.getValue());    
		} 

		//Using Hashtable
		Hashtable<Integer,String> department2=new Hashtable<Integer,String>();  
		department2.put(41,"Abhishek");  
		department2.put(23,"Ajit");  
		department2.put(77,"Aman");   

		System.out.println("\nThe Employee of Department2 are  ");  
		for(Map.Entry format:department2.entrySet()){    
			System.out.println(format.getKey()+" "+format.getValue());    
		} 
		
		//Using TreeMap
		TreeMap<Integer,String> department3=new TreeMap<Integer,String>();    
		department3.put(80,"Ravi");    
		department3.put(99,"Rahul");    
		department3.put(100,"Manish");       

		System.out.println("\nThe Employee of Department3 are ");  
		for(Map.Entry format:department3.entrySet()){    
			System.out.println(format.getKey()+" "+format.getValue());    
		}    

	}

}
