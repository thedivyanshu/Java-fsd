package PracticeProject;

import java.util.Scanner;
class BoxDetails {

	//Parameterized Constructor
	BoxDetails(double l,double b ,double h){
		double volume = l*b*h;
		System.out.println("Volume of Box -->" + volume);
	}
}

public class ConstructorMethod1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the length of box");
		double l = sc.nextDouble();
		System.out.println("Enter the breadth of box");
		double b = sc.nextDouble();
		System.out.println("Enter the height of box");
		double h = sc.nextDouble();
		BoxDetails volume = new BoxDetails(l,b,h);
	}

}
