package PracticeProject;
import java.util.Scanner;

class BoxInfo {

	//Default constructor
	BoxInfo(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length of box");
		double l = sc.nextDouble();
		System.out.println("Enter the breadth of the box");
		double b = sc.nextDouble();
		System.out.println("Enter the height of the box");
		double h = sc.nextDouble();
		double volume = l*b*h;
		System.out.println("Volume of the box is -->" + volume);
	}

}
public class ConstructorMethod2 {

	public static void main(String[] args) {

		BoxInfo volume = new BoxInfo();

	}

}
