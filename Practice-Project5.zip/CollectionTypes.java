package PracticeProject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Vector;

public class CollectionTypes {

	public static void main(String[] args) {
		// ArrayList Collection
		ArrayList<String> name=new ArrayList<String>();
		System.out.println("Example of ArrayList collection");
		name.add("Divyanshu");
		name.add("Shubham");
		name.add("Mayank");
		System.out.println(name);

		//Vector Collection
		Vector<Integer> rollNo = new Vector();
		System.out.println("Example of Vector Collection");
		rollNo.add(23);
		rollNo.add(37);
		rollNo.add(11);
		System.out.println(rollNo);

		// LinkedList Collection
		LinkedList<String> address=new LinkedList<String>();
		System.out.println("Example of LinkedList Collection");
		address.add("Bangalore");
		address.add("Chennai");
		address.add("Pune");
		System.out.println(address);

		//Hashet Collection
		HashSet<Integer> pincode=new HashSet<Integer>();  
		System.out.println("Example of HashSet Collection");
		pincode.add(530068);
		pincode.add(600008);
		pincode.add(411008);
		System.out.println(pincode);

		//LinkedHashSet Collection
		LinkedHashSet<Integer> houseNumber=new LinkedHashSet<Integer>();
		System.out.println("Example of LinkedHashSet Collection");
		houseNumber.add(12);
		houseNumber.add(33);
		houseNumber.add(10);
		System.out.println(houseNumber);


	}

}
