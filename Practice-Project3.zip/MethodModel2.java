package PracticeProject;
import java.util.Scanner;
//with return type and without arguments 
class Person {
	double salary,bonus;
	double incrSalary () {
		return salary+bonus;
	}
}
public class MethodModel2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		Person Personobj = new Person();
		System.out.println("Enter the salary");
		Personobj.salary = sc.nextDouble();
		System.out.println("Enter the bonus");
		Personobj.bonus = sc.nextDouble();
		double finalamount=Personobj.incrSalary();
		System.out.println("Final Salary is : -->"+finalamount);
	}

}
