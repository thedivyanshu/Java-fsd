package PracticeProject;

import java.util.Scanner;
//without return type and with arguments 
class employee {

	void incrSalary (double salary,double bonus) {
		double incrSalary=salary+bonus;
		System.out.println("Final Salary is : -->"+incrSalary);
	}
}
public class MethodModel4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		employee employeeobj = new employee();
		System.out.println("Enter the salary");
		double salary = sc.nextDouble();
		System.out.println("Enter the bonus");
		double bonus = sc.nextDouble();
		employeeobj.incrSalary(salary, bonus);
		
	}

}