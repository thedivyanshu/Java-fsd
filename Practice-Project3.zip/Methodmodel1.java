package PracticeProject;

import java.util.Scanner;

//with return type and with argument 
class person {

	double incrSalary (double salary,double bonus) {
		return salary+bonus;
	}
}
public class Methodmodel1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		person Person = new person();
		System.out.println("Enter the salary");
		double salary = sc.nextDouble();
		System.out.println("Enter the bonus");
		double bonus = sc.nextDouble();
		double finalamount=Person.incrSalary(salary, bonus);
		System.out.println("Final Salary is : -->"+finalamount);
	}

}
