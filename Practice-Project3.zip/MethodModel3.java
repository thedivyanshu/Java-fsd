package PracticeProject;

import java.util.Scanner;

//without return type and without arguments 
class Employee {
	double salary,bonus;
	void incrSalary () {
		double finalamount = salary+bonus;
		System.out.println("Final Salary is : -->"+finalamount);
	}
}
public class MethodModel3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		Employee Employeeobj = new Employee();
		System.out.println("Enter the salary");
		Employeeobj.salary = sc.nextDouble();
		System.out.println("Enter the bonus");
		Employeeobj.bonus = sc.nextDouble();
		Employeeobj.incrSalary();
	}

}