package PracticeProject;

import java.util.Scanner;

class Node {
	int data;
	Node next;

	Node(int data) {
		this.data = data;
		this.next = null;
	}
}

class LinkedList {
	Node head;

	LinkedList() {
		head = null;
	}

	void insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
		} else {
			Node currentNode = head;
			while (currentNode.next != null) {
				currentNode = currentNode.next;
			}
			currentNode.next = newNode;
		}
	}

	boolean delete(int key) {
		Node currentNode = head;
		Node prev = null;

		if (currentNode != null && currentNode.data == key) {
			head = currentNode.next;
			return true;
		}

		while (currentNode != null && currentNode.data != key) {
			prev = currentNode;
			currentNode = currentNode.next;
		}

		if (currentNode == null) {
			System.out.println("Key not found in the list.");
			return false;
		}
		prev.next = currentNode.next;
		return true;
	}

	void display() {
		Node currentNode = head;
		while (currentNode != null) {
			System.out.print(currentNode.data + " -> ");
			currentNode = currentNode.next;
		}
		System.out.println("null");
	}
}

public class SinglyLinkedList {
	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of elements in the linked list: ");
		int numOfElements = sc.nextInt();

		System.out.println("Enter the elements:");
		for (int i = 0; i < numOfElements; i++) {
			int element = sc.nextInt();
			list.insert(element);
		}

		System.out.println("Enter the key to be deleted: ");
		int key = sc.nextInt();

		System.out.println("Original Linked List:");
		list.display();

		boolean deletionSuccessful= list.delete(key);

		if(deletionSuccessful) {
			System.out.println("Linked List after deleting key " + key + ":");
			list.display();
			sc.close();
		}
	}
}