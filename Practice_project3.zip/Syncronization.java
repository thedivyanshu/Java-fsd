package PracticeProject;

class Counter {
	int count = 0;

	public synchronized void increment() {
		count++; 
	}
}

public class Syncronization {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Counter counter = new Counter();

		Thread threadObj1 = new Thread(new Runnable() {
			public void run() {
				for(int i=0; i<1000; i++) {
					counter.increment();
				}
			}
		});

		Thread threadObj2 = new Thread(new Runnable() {
			public void run() {
				for(int i=0; i<1000; i++) {
					counter.increment();
				}
			}
		});

		threadObj1.start();
		threadObj2.start();

		threadObj1.join();
		threadObj2.join();

		System.out.println(counter.count);

	}
}

