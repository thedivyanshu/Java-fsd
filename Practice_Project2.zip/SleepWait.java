package PracticeProject;

public class SleepWait {

	private static  Object Lock = new Object();

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		System.out.println("Thread is starting");
		Thread.sleep(3000);  
		System.out.println("Thread 1 slept for 3 seconds");  
		synchronized(Lock) {
			Lock.wait(1000); 
			System.out.println("Thread 2 waited For 1 Second");
		}
	}

}


