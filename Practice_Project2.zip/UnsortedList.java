package PracticeProject;

import java.util.Scanner;

public class UnsortedList {
	// Function to find the k-th smallest element in the array using quickselect algorithm
	public static int smallestElement(int[] arr, int left, int right, int k) {
		// Check if k is within a valid range
		if (k > 0 && k <= right - left + 1) {
			int pivotIndex = partitionOfArray(arr, left, right);

			if (k - 1 == pivotIndex - left) {
				return arr[pivotIndex];
			}

			if (k - 1 < pivotIndex - left) {
				return smallestElement(arr, left, pivotIndex - 1, k);
			} else {
				return smallestElement(arr, pivotIndex + 1, right, k - (pivotIndex - left + 1));
			}
		}

		return -1;
	}

	// Function to partition the array for quickselect
	public static int partitionOfArray(int[] arr, int left, int right) {
		int pivot = arr[right];
		int i = left - 1;

		for (int j = left; j < right; j++) {
			if (arr[j] <= pivot) {
				i++;
				swap(arr, i, j);
			}
		}

		swap(arr, i + 1, right);
		return i + 1;
	}

	// Function to swap two elements in the array
	public static void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of elements: ");
		int n = sc.nextInt();
		int[] arr = new int[n];

		System.out.println("Enter the elements:");

		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}

		int k = 4; // Find the 4th smallest element
		int smallestElement = smallestElement(arr, 0, n - 1, k);

		if (smallestElement != -1) {
			System.out.println("The 4th smallest element is: " + smallestElement);
		}
		sc.close();
	}
}

