package PracticeProject;

public class InnerClasses {
	private int length=10;
	private int breadth = 20;
	class inner{
		void area() {
			System.out.println("Area of Rectangle ="+(length*breadth));
		}

	}
	public static void main(String[] args) {

		InnerClasses object1 = new InnerClasses();
		InnerClasses.inner object2= object1.new inner();
		object2.area();

	}

}
