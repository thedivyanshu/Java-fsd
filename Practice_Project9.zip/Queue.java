package dataStructure;

import java.util.Scanner;

public class Queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the Queue");
		int size = sc.nextInt();
		int queue[] = new int[size];
		int rear = -1;
		int front = 0;
		System.out.println("Queue Operations");
		while(true) {
			System.out.println();
			System.out.println("Enter your Choice 1.Enqueue 2.Dequeue 3.Display 4.Exit");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:if(rear==size-1) {
				System.out.println("The Queue is Overflow");
			}
			else {
				System.out.println("Enter the elements into the Queue:");
				int key =sc.nextInt();
				rear++;
				queue[rear]=key;
			}
			break;
			case 2:if(rear==-1) {
				System.out.println("Queue is in Underflow");
			}
			else {
				System.out.println("The element deleted is"+queue[front]);
				front=front+1;
			}
			break;
			case 3: if(rear==-1) {
				System.out.println("Queue is empty ");
			}
			else {
				for(int i=front;i>=0;i--) {
					System.out.print(queue[i]+"-->");
				}
			}
			break;
			case 4:System.exit(0);
			break;
			default:System.out.println("check ur choice ");
			break;
			}
		}
	}
}
