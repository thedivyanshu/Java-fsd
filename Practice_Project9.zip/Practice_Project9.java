package PracticeProject;

public class DiamondProblem {
	interface one 
	{  
		default void show() 
		{ 
			System.out.println("This is my First Argument"); 
		} 
	} 
	interface two 
	{  
		default void show() 
		{ 
			System.out.println("This is my Second Argument"); 
		} 
	}  
	public static class diamondProblem implements one, two {

		public void show() 
		{  
			one.super.show(); 
			two.super.show(); 
		} 
		public static void main(String args[]) 
		{ 
			diamondProblem diamondProblemObj = new diamondProblem(); 
			diamondProblemObj.show(); 
		} 
	}

}
