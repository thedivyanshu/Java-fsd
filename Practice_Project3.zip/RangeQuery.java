package PracticeProject;

import java.util.Scanner;

public class RangeQuery {
	public static int findRangeSum(int[] array, int start, int end) {
		int sum = 0;
		for (int i = start; i <= end; i++) {
			sum += array[i];
		}
		return sum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number of elements: ");
		int n = sc.nextInt();
		int[] array = new int[n];

		System.out.println("Enter the elements:");

		for (int i = 0; i < n; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println("Enter a range query (start and end index):");
		String input = sc.next();
		int start = Integer.parseInt(input);
		int end = sc.nextInt();

		if (start < 0 || start >= n || end < 0 || end >= n || start > end) {
			System.out.println("Invalid range. Please enter a valid range.");
		} else {
			int result = findRangeSum(array, start, end);
			System.out.println("Sum of elements in the range: " + result);
		}
		sc.close();
	}


}
