package PracticeProject;


class accessmodifiers{
	int number1 = 20;
	public int number2 = 50;
	private int number3 = 100;
	protected double number4 = 200.10;

	void display() {
		System.out.println("Default variable is -->" + number1);
		System.out.println("Public variable is -->" + number2);
		System.out.println("Private variable is -->" + number3);
		System.out.println("Protected variable is -->" +number4);
	}
}
public class AcessModifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		accessmodifiers modifiersobj = new accessmodifiers();
		modifiersobj.display();

	}

}
