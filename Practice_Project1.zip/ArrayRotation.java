package PracticeProject;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayRotation {
	// Rotate the array by the specified number of steps
	public static int[] arrayRotattionBySteps(int[] arr, int steps) {
		int lengthOfArray = arr.length;
		int[] rotatedArray = new int[lengthOfArray];
		for (int i = 0; i < lengthOfArray; i++) {
			int newIndex = (i + steps) % lengthOfArray;
			rotatedArray[newIndex] = arr[i];
		}

		return rotatedArray;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		// Input the number of elements of the array
		System.out.println("Enter the number of elements in the array: ");
		int numOfElements = sc.nextInt();
		int[] originalArray = new int[numOfElements];

		// Input the elements of the array
		System.out.println("Enter the elements of the array:");
		for (int i = 0; i < numOfElements; i++) {
			originalArray[i] = sc.nextInt();
		}
		// Input the number of rotation steps
		System.out.print("Enter the number of rotation steps: ");
		int numberOfSteps = sc.nextInt();

		int[] rotatedArray = arrayRotattionBySteps(originalArray, numberOfSteps);

		System.out.println("Original Array: " + Arrays.toString(originalArray));
		System.out.println("Rotated Array: " + Arrays.toString(rotatedArray));
		sc.close();
	}

}
