package PracticeProject;

import java.util.Scanner;

public class ExceptionHandling {
	public static int divideNumbers(int num1, int num2) {
		return num1 / num2;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Enter the numerator: ");
			int num1 = scanner.nextInt();
			System.out.print("Enter the denominator: ");
			int num2 = scanner.nextInt();
			int result = divideNumbers(num1, num2);
			System.out.println("Result of the division: " + result);
		} 
		catch (ArithmeticException e) {
			System.err.println("Error: Division by zero is not allowed.");
		} 
		catch (java.util.InputMismatchException e) {
			System.err.println("Error: Invalid input. Please enter valid numbers.");
		} 
		finally {
			scanner.close();
		}
	}

}
