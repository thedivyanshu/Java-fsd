package fileIO;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileCreation {
	private String fileName;
	public FileCreation(String fileName) {
		this.fileName=fileName;
	}
	public void fileCreation() throws IOException  {
		FileOutputStream fileObj=null;
		try {
			fileObj = new FileOutputStream(fileName);
			if (fileObj!=null) {
				System.out.println("You have succesfully created a file named:"+fileName);
			}
		}
		catch(Exception e){
			e.printStackTrace();

		}
		finally {
			fileObj.close();

		}
	}
}
