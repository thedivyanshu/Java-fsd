package fileIO;

import java.io.FileWriter;
import java.io.IOException;

public class UpdateFile {
	private String fileName;

	public UpdateFile(String fileName) {
		this.fileName = fileName;
	}

	public void updateFile(String data) throws IOException {
		FileWriter update=null;
		try {
			update = new FileWriter(fileName, false); 
			update.write(data);
			System.out.println("File has been updated with new data: " + fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			update.close();
		}
	}
}
