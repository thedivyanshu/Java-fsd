package PracticeProject;

import java.util.Scanner;

class DoublyLinkedList {
	static class Node {
		int data;
		Node next;
		Node prev;

		Node(int data) {
			this.data = data;
			this.next = null;
			this.prev = null;
		}
	}

	Node head;
	Node tail;

	DoublyLinkedList() {
		head = null;
		tail = null;
	}

	void insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;
		}
	}

	void displayForward() {
		System.out.println("Doubly Linked List (Forward):");
		Node current = head;
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}

	void displayBackward() {
		System.out.println("Doubly Linked List (Backward):");
		Node current = tail;
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.prev;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		DoublyLinkedList list = new DoublyLinkedList();

		System.out.println("Enter elements to insert into the doubly linked list (enter 0 to stop):");
		int data;
		while (true) {
			data = sc.nextInt();
			if (data == 0) {
				break;
			}
			list.insert(data);
		}
		list.displayForward();
		list.displayBackward();
		sc.close();
	}
}

