package fileIO;

import java.io.FileWriter;
import java.io.IOException;

public class FileWrite {
	private String fileName;
	
	public FileWrite(String fileName) {
		super();
		this.fileName = fileName;
	}

	public void writeToFile(String writeData) throws IOException {
		FileWriter writeToFile  = null;
		try {
			writeToFile = new FileWriter(fileName);
			writeToFile.write(writeData);
			System.out.println("You have Successfully written to your file named:"+fileName);
		}
		catch (Exception e){
			e.printStackTrace();
		}
		finally {
			writeToFile.close();
		}
	}
}
