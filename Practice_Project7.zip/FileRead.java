package fileIO;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileRead {
	private String fileName;
	
	public FileRead(String fileName) {
		super();
		this.fileName = fileName;
	}

	 void readFile() throws IOException {
		FileInputStream readFile= null;
		try {
			readFile = new FileInputStream(fileName);
			Scanner sc = new Scanner(readFile);
			while(sc.hasNextLine()) {
				String content = sc.nextLine();
				System.out.println("Data in your file is:\n"+content);
				
			}
			sc.close();
		}
	
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			readFile.close();
			
		}
		}
}