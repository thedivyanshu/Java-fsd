package fileIO;

import java.io.File;

public class DeleteFile {
	private String fileName;

	public DeleteFile(String fileName) {
		this.fileName = fileName;
	}

	public void deleteFile() {
		File fileToDelete = null;
		try {
			fileToDelete = new File(fileName);
			if (fileToDelete.delete()) {
				System.out.println("File has been deleted: " + fileName);
			} 
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
