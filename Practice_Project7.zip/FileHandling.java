package fileIO;

import java.io.IOException;
import java.util.Scanner;

public class FileHandling {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the name of file to be created");
		String fileName = sc.nextLine();
		//Create a file
		FileCreation filecreationObj = new FileCreation(fileName);
		filecreationObj.fileCreation();
		//Write Data
		System.out.println("Enter the data to be inserted in the file");
		String writeData = sc.nextLine();
		FileWrite fileWriteObj = new FileWrite(fileName);
		fileWriteObj.writeToFile(writeData);
		//Read Data
		FileRead fileReadObj = new FileRead(fileName);
		fileReadObj.readFile();
		//Update File
		System.out.println("Enter the data to be updated in the file");
		String updateData = sc.nextLine();
		UpdateFile updateFileObj = new UpdateFile(fileName);
		updateFileObj.updateFile(updateData);
		//Read New Data
		FileRead fileReadObj1 = new FileRead(fileName);
		fileReadObj1.readFile();
		//Delete File
		DeleteFile deleteFileObj = new DeleteFile(fileName);
		deleteFileObj.deleteFile();
		sc.close();

	}
}


