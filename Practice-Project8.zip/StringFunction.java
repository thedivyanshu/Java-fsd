package PracticeProject;

public class StringFunction {

	public static void main(String[] args) {

		String string_var1 ="Welcome to Java String Class";
		String string_var2 = "Here We have StringBuilder and StringBuffer Topic Covered Today";


		System.out.println("String operations are:");
		System.out.println(string_var1.charAt(2));
		System.out.println(string_var1.codePointAt(3));
		System.out.println(string_var1.codePointBefore(1));
		System.out.println(string_var1.codePointCount(0, 5));
		System.out.println("\nstring comparision functions");
		System.out.println(string_var1.compareTo(string_var2));
		System.out.println(string_var1.compareToIgnoreCase(string_var2));
		System.out.println("\nConcatenated String");
		System.out.println(string_var1.concat(string_var2));
		System.out.println(string_var1.contains(string_var2));
		System.out.println(string_var1.endsWith("uffer"));
		System.out.println(string_var1.equals(string_var2));
		System.out.println(string_var1.equalsIgnoreCase(string_var2));
		System.out.println(string_var1.hashCode());
		System.out.println(string_var1.indexOf("Java"));
		String string_var3="stringbuffer";
		String replace=string_var2.replace("StringBuffer", "stringbuffer");
		System.out.println(replace);
		System.out.println(string_var1.isEmpty());

		//Creating String Buffer
		System.out.println("\nChanging String to StringBuffer");
		StringBuffer string_var4=new StringBuffer(string_var1);
		string_var4.append(" Enjoy your learning");
		System.out.println(string_var4);

		System.out.println("\nChanging String to StringBuilder");
		StringBuilder string_var5=new StringBuilder(string_var2);
		string_var5.append(" Hope you enjoy the class.");
		System.out.println(string_var5);




	}

}
