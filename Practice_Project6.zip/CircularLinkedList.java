package PracticeProject;
import java.util.Scanner;

class CircularLinkedList {
	static class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
			this.next = null;
		}
	}

	Node head;

	CircularLinkedList() {
		head = null;
	}

	void insertSorted(int data) {
		Node newNode = new Node(data);

		if (head == null) {
			head = newNode;
			head.next = head;
		} else if (data <= head.data) {
			newNode.next = head;
			head = newNode;
		} else {
			Node current = head;
			while (current.next != head && data > current.next.data) {
				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;
		}
	}

	void addNewElement(int data) {
		Node newNode = new Node(data);

		if (head == null) {
			head = newNode;
			head.next = head;
		} else if (data <= head.data) {
			newNode.next = head;
			head = newNode;
		} else {
			Node current = head;
			while (current.next != head && data > current.next.data) {
				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;
		}
	}

	void display() {
		if (head == null) {
			System.out.println("Circular Linked List is empty.");
			return;
		}

		Node current = head;
		do {
			System.out.print(current.data + " ");
			current = current.next;
		} while (current != head);

		System.out.println();
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CircularLinkedList list = new CircularLinkedList();

		System.out.println("Enter elements to insert into the circular linked list (enter 0 to stop):");
		int data;
		while (true) {
			data = sc.nextInt();
			if (data == 0) {
				break;
			}
			list.insertSorted(data);
		}

		System.out.println("Sorted Circular Linked List:");
		list.display();

		System.out.println("Enter a new element to add to the sorted circular linked list:");
		int newElement = sc.nextInt();
		list.addNewElement(newElement);

		System.out.println("Updated Sorted Circular Linked List:");
		list.display();
		sc.close();
	}
}
