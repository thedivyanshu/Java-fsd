package PracticeProject;

public class TypeCasting {

	public static void main(String[] args) {
		//implicit typecasting
		int number1=100;
		double number2=number1;
		System.out.println("Implicit Typecasting-->" +number2);

		//explicit typecasting
		double number3 = 196.08;
		int number4 = (int)number3;
		System.out.println("Explicit Typecasting-->" +number4);


	}

}
